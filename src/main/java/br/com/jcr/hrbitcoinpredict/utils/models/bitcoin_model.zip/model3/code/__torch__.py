class MLP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  features : __torch__.torch.nn.modules.container.Sequential
  out : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  def forward(self: __torch__.MLP,
    x: Tensor) -> Tensor:
    features = self.features
    feature = (features).forward(x, )
    out = self.out
    return (out).forward(feature, )
